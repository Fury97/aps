//-------------------------------------------------------------------------------------
//Name:tipsWindow 2.0
//Author:By Await 
//Date:2010-11-18
//WebSite:http://leotheme.cn
//---------------------------------------------------------------------------------------
/*说明:
 *之前的版本存在很多Bug,代码也很乱.这次重写了代码；
 *2.0经过几天的测试，没发现什么问题，当然。大家遇到问题请通知我；
 *调用方法例子里已经做了说明；
 *在这里说下有些注意的地方：
 * 1.外部关闭弹出层方法：jQuery.tipsWindow.removeBox();
 * 2.在.net下如果出现一闪就没了请在事件里加"return false"阻止默认事件;
 * 3.___fns:function(){}要在给定___closeID的时候才能回调；默认关闭时不会执行的;
 * 4.用url方式在Chrome浏览器下数据出错时请在SERVER端调用;
---------------------------------------------------------------------------------------*/
jQuery = $;
;(function(){	   
	jQuery.tipsWindow=function(options){
		options = jQuery.extend({
			___title: "Hello World",	//窗口标题文字
			___content: "text:内容",	//内容(可选内容为){ text | id | img | url | iframe }
			___width: "300",			//窗口宽度
			___height: "200",			//窗口离度
			___titleClass: "boxTitle",	//窗口标题样式名称
			___closeID:"",				//关闭窗口ID
			___time:"",					//自动关闭等待时间
			___drag:"",					//拖动手柄ID
			___showbg:false,			//是否显示遮罩层
			___fns:function(){}			//关闭窗口后执行的函数
		},options);
		if (jQuery('#___box').length==0)jQuery.tipsWindow.init(options);
	};
	jQuery.extend(jQuery.tipsWindow,{
		//初始化
		init: function (options){
			jQuery.tipsWindow.showBox(options);
			jQuery("#___boxTitle>span").live("click",function(){	//默认关闭按钮
				jQuery.tipsWindow.removeBox();
			});
			if(options.___closeID != ""){
				jQuery("#"+options.___closeID).live("click",function(){	
					if(options.___fns != "" && jQuery.isFunction(options.___fns)) {
						options.___fns.call(this);
					}
					jQuery.tipsWindow.removeBox();
				});
			}
			if(options.___time != "") {
				setTimeout(jQuery.tipsWindow.removeBox,options.___time);
			}
			if(options.___showbg != "" && options.___showbg == true){
				var jQueryboxBgDom = "<div id=\"boxBg\" style=\"position:absolute;width:100%;height:"+jQuery(document).height()+"px;left:0;top:0;z-index: 999991\"></div>";
				jQuery("body").append(jQueryboxBgDom);
			}
			if(options.___drag != "") {
				jQuery.tipsWindow.dragBox(options);
			};
			if(options.___showbg != true){
				jQuerybox = jQuery("#___box");
				jQuerybox.addClass("shadow");
			}
			jQuery.tipsWindow.contentBox(options);
			jQuery.tipsWindow.keyDown();
		},
		//构造并定位弹出层
		showBox: function(options) {
			var isIE6 = !-[1,] && !window.XMLHttpRequest;
			var	___width = options.___width < 100 ? 100 : options.___width,
				___height= options.___height < 50 ? 50 : options.___height;//设置最小宽高
			var jQuerywidth = parseInt(options.___width)+2 > 1000 ? parseInt(options.___width)+2 : parseInt(options.___width)+2,
				jQueryheight = parseInt(options.___height)+33 > 550 ? 550 : parseInt(options.___height)+33;//设置最大宽高
			var jQueryboxDom = "<div id=\"___box\" class=\"box\">";
				jQueryboxDom += "<div id=\"___boxTitle\"><h3></h3><span>关闭</span></div>";
				jQueryboxDom += "<div id=\"___boxContent\" class=\"boxContent\"></div>";
				jQueryboxDom += "</div>";
				jQuery("body").append(jQueryboxDom);
			var jQuerybox = jQuery("#___box"),
				jQueryboxContent = jQuery("#___boxContent");
				jQueryboxContent.css({
					width:___width+"px",
					height:___height+"px"
				});
			if(!isIE6){
				jQuerybox.css({
					position:"fixed",
					left:"50%",
					top:"50%",
					width:jQuerywidth+"px",
					height:jQueryheight+"px",
					marginLeft:-(parseInt(jQuerywidth/2))+"px",
					marginTop:-(parseInt(jQueryheight/2)+5)+"px",
					zIndex: "999999"
				});
			}else{
				jQuerybox.css({
					position:"absolute",
					left:"50%",
					top:document.documentElement.offsetHeight/2-jQueryheight/2-5+"px",
					width:jQuerywidth+"px",
					height:jQueryheight+"px",
					marginLeft:-(parseInt(jQuerywidth/2))+"px",
					zIndex: "999999"
				});
				jQuery(window).resize(function(){//当窗口大小发生变化时修正top值
					jQuerybox.css({
						top:document.documentElement.offsetHeight/2-jQueryheight/2-5+"px"
					});
				});
				jQuery("select").css("visibility","hidden");//IE6下隐藏下拉菜单
				jQuery("body").css("background-attachment","fixed").css("background-image","url(about:blank)");
				var jQuerylayer = document.createElement("<div style='position:absolute;border:0;padding:0;margin:0;overflow:hidden;background:transparent;top:expression((document).documentElement.scrollTop);left:expression((document).documentElement.scrollLeft);width:expression((document).documentElement.clientWidth);height:expression((document).documentElement.clientHeight);display:block;z-index:999992'>");
				jQuery("body").append(jQuerylayer);
				jQuerybox.appendTo(jQuerylayer);//IE6下Fixed定位
			}
			var jQuerytitle = jQuery("#___boxTitle>h3");
				jQuerytitle.html(options.___title);
			if(options.___titleClass != ""){
				jQuerytitle.parent().addClass(options.___titleClass);
				jQuerytitle.parent().find("span").hover(function(){
					jQuery(this).addClass("hover");
				},function(){
					jQuery(this).removeClass("hover");
				});
			}
		},
		//关闭弹出层
		removeBox: function (options){
			var jQuerybox = null;
			var jQueryboxbg = null;
			var jQuerycontentType = null;
			if(options != undefined && options != null && options != ''){
				jQuerycontentType = options.___content.substring(0,options.___content.indexOf(":"));
			}
			if(jQuerycontentType == "iframe"){
				jQuerybox = jQuery(parent.document.getElementById("___box"));
				jQueryboxbg = jQuery(parent.document.getElementById("boxBg"));
			}else{
				jQuerybox = jQuery("#___box");
				jQueryboxbg = jQuery("#boxBg");
			}
			jQuery("select").css("visibility","visible");//关闭弹出层后显示下拉菜单
			if(jQuerybox != null || jQueryboxbg != null){
				jQuerybox.remove();
				jQueryboxbg.remove();
			}
		},
		//健盘事件，当按Esc的时候关闭弹出层
		keyDown: function() {
			jQuery(document).keydown(function(e) {
				e = e || event;
				if(e.keyCode == 27) jQuery.tipsWindow.removeBox();
			})
		},
		//绑定拖拽
		dragBox: function (options){
			var moveX = 0,moveY = 0,
				drag = false;
			var ___ID = document.getElementById("___box"),
				___Handle = document.getElementById(options.___drag);
			___Handle.onmouseover = function() {
				this.style.cursor = "move";
			}
			___Handle.onmousedown = function(e) {
				drag = true;
				e = window.event?window.event:e;
				moveX = e.clientX - ___ID.offsetLeft;
				moveY = e.clientY - ___ID.offsetTop;
				document.onmousemove = function(e) {
					if (drag) {
						e = window.event?window.event:e;
						window.getSelection ? window.getSelection().removeAllRanges() : document.selection.empty();//阻止浏览器默认选取
						var x = e.clientX - moveX;
						var y = e.clientY - moveY;
						if ( x > 0 &&( x + ___ID.scrollWidth < document.documentElement.clientWidth) && y > 0 && y + ___ID.scrollHeight < document.documentElement.clientHeight ) {
							___ID.style.left = x + "px";
							___ID.style.top = y + "px";
							___ID.style.margin = "auto";
						}
					}
				};
				document.onmouseup = function(){
					drag = false;
				};
			};
		},
		//装载弹出层内容
		contentBox: function (options) {
			var jQuerycontentID = jQuery("#___boxContent");
				jQuerycontentType = options.___content.substring(0,options.___content.indexOf(":"));
				jQuerycontent = options.___content.substring(options.___content.indexOf(":")+1,options.___content.length);
			var isIE6 = !-[1,] && !window.XMLHttpRequest;
			switch(jQuerycontentType) {
				case "text":
					jQuerycontentID.html(jQuerycontent);
				break;
				case "id":
					jQuerycontentID.html(jQuery("#"+jQuerycontent).html());
				break;
				case "img":
				jQuerycontentID.ajaxStart(function() {
					jQuery(this).html("<p class='boxLoading'>loading...</p>");
				});
				jQuery.ajax({
					error:function(){
						jQuerycontentID.html("<p class='boxError'>加载数据出错...</p>");
					},
					success:function(html){
						jQuerycontentID.html("<img src="+jQuerycontent+" alt='' />");
					}
				});
				break;
				case "url":
				var contentDate=jQuerycontent.split("?");
				jQuerycontentID.ajaxStart(function(){
					jQuery(this).html("<p class='boxLoading'>loading...</p>");
				});
				jQuery.ajax({
					type:contentDate[0],
					url:contentDate[1],
					data:contentDate[2],
					error:function(){
						jQuerycontentID.html("<p class='boxError'>加载数据出错...</p>");
					},
					success:function(html){
						jQuerycontentID.html(html);
					}
				});
				break;
				case "iframe":
				jQuerycontentID.css({overflowY:"hidden"});
				jQuerycontentID.ajaxStart(function(){
					jQuery(this).html("<p class='boxLoading'>loading...</p>");
				});
				jQuery.ajax({
					url:jQuerycontent,
					error:function(){
						jQuerycontentID.html("<p class='boxError'>加载数据出错...</p>");
					},
					success:function(html){
						jQuerycontentID.html("<iframe name=\"tipsiframe\" src=\""+jQuerycontent+"\" width=\"100%\" height=\""+parseInt(options.___height)+"px\" scrolling=\"auto\" frameborder=\"0\" marginheight=\"0\" marginwidth=\"0\"></iframe>");
					}
				});
			}
		}
	});
})(jQuery);